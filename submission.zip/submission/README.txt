By Wilson Chang (304-845-848) and Ron Ocampo (204-743-402)
File: Q1&2-notebook answering the question does more training data help
File: Q3:notebook answering time vs accuracy
File: data_preprocessing: data preprocessing techniques
